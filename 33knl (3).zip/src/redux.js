import { createStore, applyMiddleware } from "redux";

const ADD_DATA = "ADD_DATA";

export function addData(data) {
  return {
    type: ADD_DATA,
    PayLoad: data
  };
}

let datamanager = (state = [], action) => {
  switch (action.type) {
    case "ADD_DATA":
      return [...state, action.PayLoad];
    default:
      return state;
  }
};

export const store = createStore(datamanager);
