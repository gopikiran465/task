import React, { useState } from "react";
import { useSelector, useDispatch, connect } from "react-redux";
import { addData } from "./redux";
import "./styles.css";

const App = () => {
  let [details, setDetails] = useState({ name: "", phone: "", dob: "" });
  let data = useSelector((state) => state);
  const dispatch = useDispatch();
  const handleChange = (e) => {
    let name = e.target.name;
    let value = e.target.value;
    details[name] = value;
    setDetails({ ...details });
  };

  const sendData = () => {
    dispatch(addData(details));
    setDetails({ name: "", phone: "", dob: "" });
  };

  return (
    <div className="form_div">
      <div className="form-group">
        <label>Name</label>
        <input
          type="text"
          name="name"
          className="form-control"
          onChange={(e) => handleChange(e)}
          value={"" || details.name}
          placeholder="Enter name"
        />
      </div>
      <div className="form-group">
        <label>date of birth</label>
        <input
          type="date"
          name="dob"
          onChange={handleChange}
          className="form-control"
          value={details.dob}
          placeholder="Password"
        />
      </div>
      <div className="form-group">
        <label>phone</label>
        <input
          type="number"
          name="phone"
          onChange={handleChange}
          value={details.phone}
          className="form-control"
        />
      </div>
      <button className="btn btn-primary mb-3" onClick={sendData}>
        click
      </button>

      <table className="table table-bordered">
        <thead>
          <tr>
            <td>NAME</td>
            <td>DOB</td>
            <td>MOBILE</td>
          </tr>
        </thead>
        <tbody>
          {data.map((det, i) => {
            return (
              <tr key={i}>
                <td>{det.name}</td>
                <td>{det.dob}</td>
                <td>{det.phone}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};

export default connect(null, null)(App);
